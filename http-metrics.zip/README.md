# http-metrics
This is a simple Monitoring system application
This app sends periodic HTTP request to a URL and records latency and availability for that particular URL. it is similar to pingdom.com but in a very simple and basic way. Anyone is welcome to improve this
